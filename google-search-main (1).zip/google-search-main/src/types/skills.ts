import { skills } from 'src/content'

export type Skill = typeof skills[0]
