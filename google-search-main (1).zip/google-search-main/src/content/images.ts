export const images = [
  'oTD1WibmeFM',
  'wKLFiInmCVU',
  '-PdP8SYHYIU',
  'UKu0b_VD5Jo',
  'b0KNao3FbA8',
  '_LLLOJTm8-I',
  'oqtKVFJxius',
  'QdrfPZJC78k',
  'nPMt1gLN3JU',
]
