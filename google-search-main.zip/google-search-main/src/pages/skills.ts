export { Skills as default } from 'src/screens'
