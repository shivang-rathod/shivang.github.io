export { Home as default } from 'src/screens'
