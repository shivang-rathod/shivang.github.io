export { Videos as default } from 'src/screens'
